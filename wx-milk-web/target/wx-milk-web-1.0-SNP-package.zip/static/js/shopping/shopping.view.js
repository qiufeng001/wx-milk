"use strict";
define(function (require, exports, module) {
	var text = "你好";
	
	class LoginView {
		constructor() {
			alert(text);
		}
	}
}