"use strict";
/**
 * 核心基础
 *  @module core/core
 */
define(function(require, exports, module){


});